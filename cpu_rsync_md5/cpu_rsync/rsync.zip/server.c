#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdint.h>
#include <sys/types.h>  
#include <unistd.h>

#include "checksum.h"
#include "hashtable.h"

#define USAGE               \
"usage:\n"                   \
"  server [options]\n"      \
"options:\n"                   \
"  -f [rsyn_file]  File to be rsyn\n"    \
"  -s [chunk_size] Chunk size of file\n" \
"  -h              Show this help message\n"


/* OPTIONS DESCRIPTOR ====================================================== */
static struct option gLongOptions[] = {
  {"old_file",   required_argument,      NULL,            'o'},
  {"rsyn_file",   required_argument,      NULL,           'f'},
  {"chunk_size",  required_argument,      NULL,           's'},
  {"help",        no_argument,            NULL,           'h'},
  {NULL,            0,                    NULL,            0}
};



int main(int argc, char **argv){
  int chunk_size = 512;
  char *file_path = "test.txt";
  char *rsync_file_path = "new_test.txt"; 
  int option_char = 0;
  while ((option_char = getopt_long(argc, argv, "o:f:s:h", gLongOptions, NULL)) != -1) {
    switch (option_char) {
      default:
        fprintf(stderr, "%s", USAGE);
        exit(__LINE__);
      case 's': // chunk size
        chunk_size = atoi(optarg);
        break;   
      case 'o': // file-path
        file_path = optarg;
        break;                                          
      case 'f': // file-path
        rsync_file_path = optarg;
        break;                                          
      case 'h': // help
        fprintf(stdout, "%s", USAGE);
        exit(0);
        break;
    }
  }
  printf("server start\n");
  struct stat statbuf;
  int fd;
  if((fd = open(file_path, O_RDWR, 0777)) < 0){
      fprintf(stderr, "Unable to open file in simplecache_init.\n");
      exit(1);
  }
  if (0 > fstat(fd, &statbuf)) {
      printf("file with path %s not found, continue next\n",file_path);
  }
  size_t file_len = (size_t) statbuf.st_size;  
  uint chunk_num = (file_len / chunk_size) + 1; 
  uint chunk_id = 0;
  char chunk_buffer[chunk_size];
  size_t read_size = 0;
  int i = 0;
  HashTable *ht = (HashTable *)malloc(sizeof(HashTable));
  create_hashtable(ht);
  printf("create hash table success\n");
  while(chunk_id < chunk_num){
      read_size = read(fd, chunk_buffer, chunk_size);
      if(read_size < 0){
          printf("Error in reading");
      }
      static uint32 rolling_checksum;
      rolling_checksum = get_checksum1(chunk_buffer, (int32)read_size);
      printf("rolling_checksum is %d\n",(int)rolling_checksum);
      static char sum2[16];
      get_checksum2(chunk_buffer, (int32)read_size, sum2);
      //not know why they output using a loop
      for(i=0;i<16;++i){
        //printf("md5 is %02x\n", sum2[i]); 
      }
      if((insert_hashtable(ht, chunk_id, rolling_checksum, sum2))==1){
        printf("insert success\n");
      }
      else{
        printf("insert failed\n");
      }
      chunk_id ++;
  }
  close(fd);
  //open the new file to rsync
  if((fd = open(rsync_file_path, O_RDWR, 0777)) < 0){
      fprintf(stderr, "Unable to open file in simplecache_init.\n");
      exit(1);
  }
  if (0 > fstat(fd, &statbuf)) {
      printf("file with path %s not found, continue next\n",rsync_file_path);
  }
  file_len = (size_t) statbuf.st_size;
  long int offset = 0;
  while(offset < file_len){
      printf("now offset is %ld\n",offset);
      if((lseek(fd, offset, SEEK_SET))==-1){
          printf("error in file seek\n");}
      read_size = read(fd, chunk_buffer, chunk_size);
      if(read_size < 0){
          printf("Error in reading\n");
      }
      static uint32 rolling_checksum;
      rolling_checksum = get_checksum1(chunk_buffer, (int32)read_size);
      //printf("rolling_checksum is %d\n",(int)rolling_checksum);
      Node *np = lookup_hashtable(ht, rolling_checksum);
      //not pass the first check, almost failed in this match test, showing hash func works well
      if(np == NULL){
          printf("not find in hash table\n");
          offset += 1; 
          continue;
      }
      else{
          //not pass the second check
          if(np->checksum != rolling_checksum){
              printf("checksum not match\n");
              offset += 1; 
              continue;
          }
          else{
              static char sum2[16];
              get_checksum2(chunk_buffer, (int32)read_size, sum2);
              for(i=0;i<16;++i){
                  //not pass the third check
                  if(sum2[i]!=np->md5[i]){ 
                      printf("md5 not match\n");
                      offset += 1;
                      continue;
                  }
              }
              printf("find a match\n");
              offset += read_size;
          }
      }
  }
  printf("finish match\n");
  return 0;
}













