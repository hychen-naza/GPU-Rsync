#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

#ifndef TYPE_H
#define TYPE_H
typedef unsigned int uint;
typedef uint32_t uint32;
typedef int32_t int32;
#endif
