#include "type.h"
#include <string>
#ifndef H_HASH_H
#define H_HASH_H
#define HASHSIZE 9999

typedef struct Node{
    int chunk_id;
    uint32 checksum;
    char md5[16];
    struct Node *next;
}Node;

struct Task
{
  std::string fileName;

  char *file; // old file length
  int *stat;
  int *matchChunkid;
  int *matchOffset;

  char *dFileContent;
  int *dMatchChunkid;
  int *dMatchOffset;
  Node *dHt;
  int *dStat;

  int fileLen;
  int chunkSize;
  int totalChunkNum;
  int totalThreads;
  int roundNum;

  Node *ht;

  std::map<int, std::set<int> > matchIdMap;
  int fd;
};

struct buidlTask
{
  std::string fileName;
  int chunkSize;
  int totalThreads;
  int fd;
  
  char *file;
  int *stat;
  int *matchChunkid;
  int *matchOffset;

  std::map<int, std::set<int> > matchIdMap;
};

uint hash(uint32 rc);
int lookup_ht(Node *ht, int32 rc, int *chunk_id);
int insert_hashtable(Node *ht, uint id, uint32 checksum, char md5[16], std::map<int, std::set<int> > &matchIdMap);
uint32 h_get_checksum1(char *buf1, int32 len, uint32 *d_s1, uint32 *d_s2);
__device__ uint32 d_get_checksum1(char *buf1, int32 len, uint32 *d_s1, uint32 *d_s2);
__device__ uint d_hash(uint32 rc);
__device__ int d_lookup_ht(Node *ht, int32 rc, int *chunk_id);
cudaStream_t * GPUWarmUp(int n_stream);

#endif
